﻿기내톡 (SkyTalk) - Windows 방장용

1. 비행기 모드를 켜고 Wi-Fi만 다시 켜세요. (아무 Wi-Fi에도 연결하지 않아도 돼요)
2. SkyTalk-Windows.bat 을 더블클릭하세요.
   - "Windows의 PC 보호" 창 → [추가 정보] → [실행]
   - 관리자 권한을 물으면 → [예]
3. 검은 창에 나온 Wi-Fi 이름·비밀번호·주소를 팀원에게 알려 주세요.
   팀원: 그 Wi-Fi에 연결 → Safari/Chrome 주소창에 주소 입력 → 이름 입력
4. 노트북 덮개는 닫지 말고 화면만 어둡게 해 두세요. (덮으면 절전으로 꺼질 수 있어요)

Wi-Fi 이름·비밀번호 바꾸기: SkyTalk-Windows.bat 을 메모장으로 열어 맨 위
SKYTALK_SSID, SKYTALK_PASS 를 고치세요. (비밀번호 8자 이상)

자세한 안내: https://songlomin.github.io/skytalk/
